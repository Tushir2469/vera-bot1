# Vera Challenge submission — Himanshu

A FastAPI bot implementing the 5-endpoint contract from `challenge-testing-brief.md`:
`POST /v1/context`, `POST /v1/tick`, `POST /v1/reply`, `GET /v1/healthz`, `GET /v1/metadata`
(plus an optional `POST /v1/teardown`).

Composition uses Claude (`ANTHROPIC_API_KEY`) with the 4-context framework (category,
merchant, trigger, customer) from `challenge-brief.md`, and includes:
- Auto-reply detection (same merchant message 3× → graceful exit)
- Intent-transition handling (explicit "yes/let's do it" → skip straight to action)
- Anti-repetition guard (never resend an identical body in a conversation)
- Idempotent context versioning, in-memory per-conversation state

## 1. Get the code running locally first (optional but recommended)

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...        # required for real LLM composition
uvicorn bot:app --host 0.0.0.0 --port 8080
```

Then, from the challenge zip:
```bash
export BOT_URL=http://localhost:8080
python judge_simulator.py
```
Iterate until you're happy with the scores.

## 2. Deploy to get a public URL (pick one — both are free and ~5 minutes)

### Option A — Render.com (recommended, simplest)
1. Push this folder to a GitHub repo (or use Render's "public git repo" import).
2. On render.com → **New +** → **Web Service** → connect the repo.
3. Environment: Python 3. Build command: `pip install -r requirements.txt`.
   Start command: `uvicorn bot:app --host 0.0.0.0 --port $PORT` (already in `Procfile`).
4. Add an environment variable: `ANTHROPIC_API_KEY = sk-ant-...`.
5. Deploy. Render gives you a URL like `https://your-bot.onrender.com`.
6. **That's your submission URL.** Verify first:
   `curl https://your-bot.onrender.com/v1/healthz`

### Option B — Railway.app
1. `railway login` → `railway init` in this folder → `railway up`.
2. `railway variables set ANTHROPIC_API_KEY=sk-ant-...`
3. Railway assigns a public domain (Settings → Networking → Generate Domain).
4. Submit that `https://...up.railway.app` URL.

### Option C — ngrok (fastest, but only stays up while your laptop is running the test)
```bash
uvicorn bot:app --host 0.0.0.0 --port 8080 &
ngrok http 8080
```
Submit the `https://xxxx.ngrok-free.app` URL ngrok prints. Only use this if the
challenge's test window is short and you'll be online for it — free tunnels
aren't reliable for anything long-running or unattended.

## 3. Before you submit — checklist (from §12 of the testing brief)

- [ ] `curl https://<your-url>/v1/healthz` returns 200 from a network other than your own
- [ ] `curl https://<your-url>/v1/metadata` returns your team info (edit `TEAM_NAME`,
      `VERA_TEAM_MEMBER`, `VERA_CONTACT_EMAIL` env vars, or edit the constants in `bot.py`)
- [ ] `ANTHROPIC_API_KEY` is set on the host (otherwise you'll get generic fallback
      messages, which will score poorly on specificity/category-fit)
- [ ] Set your Anthropic API spend limit/budget — the judge can send bursts of requests
- [ ] `judge_simulator.py` passes locally with non-zero scores first
- [ ] Submit the `https://...` base URL (not `/v1/...`) in the submission portal

## Notes on what's stubbed vs. real

- The composer prompt (`SYSTEM_PROMPT` in `bot.py`) encodes the brief's hard rules
  (one CTA, no taboo vocab, service+price over generic %, cite sources, language
  match, no re-intro, anti-repetition). Tune it further using the good/bad examples
  in `challenge-brief.md` §9 and Appendix A/B if you want to push scores higher.
- Multi-turn cadence planning (brief §12.3) is currently simple: one action per
  new trigger per tick, no cross-trigger sequencing. That's the next thing worth
  building if you have time before the deadline.
- Language detection mid-conversation (§12.4) is left to the LLM via the merchant's
  `identity.languages` field passed in context — not separately enforced in code.
