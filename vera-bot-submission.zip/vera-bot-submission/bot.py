"""
Vera Challenge submission bot.

Implements the 5-endpoint contract from challenge-testing-brief.md:
  POST /v1/context
  POST /v1/tick
  POST /v1/reply
  GET  /v1/healthz
  GET  /v1/metadata

Composition is delegated to Claude (via the Anthropic API) using the
4-context framework (category, merchant, trigger, customer) described in
challenge-brief.md. Falls back to a deterministic template if no API key
is configured, so the bot never crashes during judging.

Run locally:
    pip install -r requirements.txt
    export ANTHROPIC_API_KEY=sk-ant-...
    uvicorn bot:app --host 0.0.0.0 --port 8080

Then point judge_simulator.py (BOT_URL=http://localhost:8080) at it.
"""

import os
import re
import time
import json
import uuid
from datetime import datetime, timezone
from typing import Any, Literal, Optional

from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI(title="Vera Challenge Bot")

START = time.time()

# ---------------------------------------------------------------------------
# In-memory state (fine per the brief: "storing in memory is fine; just
# don't restart between calls"). Wiped on POST /v1/teardown.
# ---------------------------------------------------------------------------

# (scope, context_id) -> {"version": int, "payload": dict}
contexts: dict[tuple[str, str], dict] = {}

# conversation_id -> {"turns": [...], "sent_bodies": set(), "merchant_id":..,
#                      "customer_id":.., "trigger_id":.., "last_auto_reply_streak": 0}
conversations: dict[str, dict] = {}

# suppression_key -> last tick time we fired it, to avoid re-sending the
# same nudge every tick within its natural cadence.
suppression_fired: dict[str, str] = {}

TEAM_NAME = os.environ.get("VERA_TEAM_NAME", "Team Solo")
TEAM_MEMBERS = [os.environ.get("VERA_TEAM_MEMBER", "Himanshu")]
CONTACT_EMAIL = os.environ.get("VERA_CONTACT_EMAIL", "you@example.com")
ANTHROPIC_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-5")


# ---------------------------------------------------------------------------
# LLM composer
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are Vera, magicpin's WhatsApp assistant for local merchants (and \
sometimes their customers). You compose ONE outbound WhatsApp message given four context \
layers: category, merchant, trigger, and (optionally) customer.

Hard rules (violating any of these is scored as a failure):
- Exactly ONE call-to-action, and it must be the LAST sentence.
- Use the category's allowed vocabulary; NEVER use taboo words/phrases for that category.
- Prefer service+price offers ("Haircut @ Rs99") over generic discount language ("10% off").
- Cite concrete numbers/dates/sources when you have them (specificity beats vagueness).
- Never invent facts, sources, competitors, or numbers that are not in the given context.
- Match the merchant's/customer's language preference (hi-en code-mix if languages include "hi").
- No long preambles ("I hope you are doing well..."). Get to the point in sentence one.
- Do not re-introduce yourself if conversation_history already shows prior turns.
- Never repeat a message verbatim that has already been sent in this conversation (you will be \
told prior bodies sent).
- If replying to an explicit affirmative ("yes", "let's do it", "go ahead", "ok start"), do NOT \
ask another qualifying question — move straight to action / next concrete step.
- Use at least one compulsion lever: specificity, loss aversion, social proof, effort \
externalization, curiosity, reciprocity, asking the merchant a question, or a single binary ask.

Respond with ONLY a JSON object, no markdown fences, no commentary:
{"body": "...", "cta": "open_ended"|"binary"|"scheduling", "rationale": "one sentence"}
"""


def _anthropic_client():
    try:
        import anthropic  # type: ignore
    except ImportError:
        return None
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return None
    return anthropic.Anthropic(api_key=api_key)


def llm_compose(user_prompt: str) -> dict:
    """Call Claude to compose a message. Falls back to a safe deterministic
    stub if no API key / package is available, so the bot stays functional
    for the judge even without LLM credentials configured."""
    client = _anthropic_client()
    if client is None:
        return {
            "body": "Quick one for you — worth a look when you get a minute. Want the details?",
            "cta": "open_ended",
            "rationale": "fallback composer (no LLM configured)",
        }
    try:
        resp = client.messages.create(
            model=ANTHROPIC_MODEL,
            max_tokens=400,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_prompt}],
        )
        text = "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
        text = text.strip()
        text = re.sub(r"^```(json)?", "", text).strip()
        text = re.sub(r"```$", "", text).strip()
        data = json.loads(text)
        if "body" not in data or not data["body"]:
            raise ValueError("empty body")
        return data
    except Exception as e:  # noqa: BLE001 - never let a bad LLM call crash a tick
        return {
            "body": "Quick update for you — worth a look when you get a minute. Want the details?",
            "cta": "open_ended",
            "rationale": f"fallback composer (llm error: {e})",
        }


def get_ctx(scope: str, context_id: Optional[str]) -> Optional[dict]:
    if not context_id:
        return None
    entry = contexts.get((scope, context_id))
    return entry["payload"] if entry else None


def build_compose_prompt(
    category: Optional[dict],
    merchant: Optional[dict],
    trigger: Optional[dict],
    customer: Optional[dict],
    prior_bodies: list[str],
    extra_instruction: str = "",
) -> str:
    parts = [
        "CATEGORY_CONTEXT:\n" + json.dumps(category, ensure_ascii=False) if category else "CATEGORY_CONTEXT: none",
        "MERCHANT_CONTEXT:\n" + json.dumps(merchant, ensure_ascii=False) if merchant else "MERCHANT_CONTEXT: none",
        "TRIGGER_CONTEXT:\n" + json.dumps(trigger, ensure_ascii=False) if trigger else "TRIGGER_CONTEXT: none",
        "CUSTOMER_CONTEXT:\n" + json.dumps(customer, ensure_ascii=False) if customer else "CUSTOMER_CONTEXT: none",
        "PRIOR_BODIES_SENT_THIS_CONVERSATION:\n" + json.dumps(prior_bodies, ensure_ascii=False),
    ]
    if extra_instruction:
        parts.append("INSTRUCTION:\n" + extra_instruction)
    parts.append("Compose the single next WhatsApp message now, as the JSON object described.")
    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# Auto-reply / intent detection helpers (Section 12 open challenges)
# ---------------------------------------------------------------------------

AFFIRM_PATTERNS = re.compile(
    r"\b(yes|haan|ok(ay)?|go ahead|let'?s do it|sure|start karo|kar do|i want to join|"
    r"join karna hai|proceed)\b",
    re.IGNORECASE,
)

NOT_INTERESTED_PATTERNS = re.compile(
    r"\b(not interested|no thanks|stop|band karo|nahi chahiye|unsubscribe|leave me alone)\b",
    re.IGNORECASE,
)


def looks_like_auto_reply(conv: dict, message: str) -> bool:
    """Same message verbatim 3+ times from the merchant side => auto-reply."""
    merchant_msgs = [t["message"] for t in conv["turns"] if t["from_role"] == "merchant"]
    merchant_msgs.append(message)
    same_count = sum(1 for m in merchant_msgs if m.strip().lower() == message.strip().lower())
    return same_count >= 3


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@app.get("/v1/healthz")
async def healthz():
    counts: dict[str, int] = {"category": 0, "merchant": 0, "customer": 0, "trigger": 0}
    for (scope, _cid) in contexts.keys():
        counts[scope] = counts.get(scope, 0) + 1
    return {
        "status": "ok",
        "uptime_seconds": int(time.time() - START),
        "contexts_loaded": counts,
    }


@app.get("/v1/metadata")
async def metadata():
    return {
        "team_name": TEAM_NAME,
        "team_members": TEAM_MEMBERS,
        "model": ANTHROPIC_MODEL,
        "approach": "single-prompt composer over the 4-context framework, with "
        "auto-reply detection, intent-transition handling, and anti-repetition guards",
        "contact_email": CONTACT_EMAIL,
        "version": "0.1.0",
        "submitted_at": datetime.now(timezone.utc).isoformat(),
    }


class CtxBody(BaseModel):
    scope: Literal["category", "merchant", "customer", "trigger"]
    context_id: str
    version: int
    payload: dict[str, Any]
    delivered_at: str


@app.post("/v1/context")
async def push_context(body: CtxBody):
    key = (body.scope, body.context_id)
    cur = contexts.get(key)
    if cur and cur["version"] >= body.version:
        return {
            "accepted": False,
            "reason": "stale_version",
            "current_version": cur["version"],
        }
    contexts[key] = {"version": body.version, "payload": body.payload}
    return {
        "accepted": True,
        "ack_id": f"ack_{body.context_id}_v{body.version}",
        "stored_at": datetime.now(timezone.utc).isoformat(),
    }


@app.post("/v1/teardown")
async def teardown():
    contexts.clear()
    conversations.clear()
    suppression_fired.clear()
    return {"wiped": True}


class TickBody(BaseModel):
    now: str
    available_triggers: list[str] = Field(default_factory=list)


@app.post("/v1/tick")
async def tick(body: TickBody):
    actions = []
    for trg_id in body.available_triggers:
        trigger = get_ctx("trigger", trg_id)
        if not trigger:
            continue

        supp_key = trigger.get("suppression_key", trg_id)
        if suppression_fired.get(supp_key) == trg_id:
            continue  # already actioned this exact trigger once

        merchant_id = trigger.get("merchant_id")
        customer_id = trigger.get("customer_id")
        merchant = get_ctx("merchant", merchant_id)
        if not merchant:
            continue
        category = get_ctx("category", merchant.get("category_slug"))
        if not category:
            continue
        customer = get_ctx("customer", customer_id) if customer_id else None

        conversation_id = f"conv_{merchant_id}_{trg_id}"
        if conversation_id in conversations:
            continue  # don't restart an existing conversation from a tick

        prompt = build_compose_prompt(category, merchant, trigger, customer, prior_bodies=[])
        result = llm_compose(prompt)

        action = {
            "conversation_id": conversation_id,
            "merchant_id": merchant_id,
            "customer_id": customer_id,
            "send_as": "merchant_on_behalf" if customer_id else "vera",
            "trigger_id": trg_id,
            "template_name": f"vera_{trigger.get('kind', 'generic')}_v1",
            "template_params": [merchant.get("identity", {}).get("name", "")],
            "body": result["body"],
            "cta": result.get("cta", "open_ended"),
            "suppression_key": supp_key,
            "rationale": result.get("rationale", ""),
        }
        actions.append(action)

        conversations[conversation_id] = {
            "turns": [{"from_role": "vera", "message": result["body"]}],
            "sent_bodies": {result["body"]},
            "merchant_id": merchant_id,
            "customer_id": customer_id,
            "trigger_id": trg_id,
            "auto_reply_streak": 0,
        }
        suppression_fired[supp_key] = trg_id

        if len(actions) >= 20:  # cap per §5 rate limits
            break

    return {"actions": actions}


class ReplyBody(BaseModel):
    conversation_id: str
    merchant_id: Optional[str] = None
    customer_id: Optional[str] = None
    from_role: str
    message: str
    received_at: str
    turn_number: int


@app.post("/v1/reply")
async def reply(body: ReplyBody):
    conv = conversations.setdefault(
        body.conversation_id,
        {
            "turns": [],
            "sent_bodies": set(),
            "merchant_id": body.merchant_id,
            "customer_id": body.customer_id,
            "trigger_id": None,
            "auto_reply_streak": 0,
        },
    )
    conv["turns"].append({"from_role": body.from_role, "message": body.message})

    # --- Open challenge 1: auto-reply detection -----------------------
    if looks_like_auto_reply(conv, body.message):
        conv["auto_reply_streak"] += 1
        return {
            "action": "end",
            "rationale": "Detected repeated identical merchant reply (likely WhatsApp "
            "Business auto-reply); exiting gracefully rather than burning turns.",
        }

    # --- Not-interested / stop -----------------------------------------
    if NOT_INTERESTED_PATTERNS.search(body.message):
        return {
            "action": "end",
            "rationale": "Merchant signaled not-interested/stop; ending conversation.",
        }

    merchant = get_ctx("merchant", conv.get("merchant_id"))
    category = get_ctx("category", merchant.get("category_slug")) if merchant else None
    customer = get_ctx("customer", conv.get("customer_id")) if conv.get("customer_id") else None
    trigger = get_ctx("trigger", conv.get("trigger_id")) if conv.get("trigger_id") else None

    # --- Open challenge 2: intent-transition handling -------------------
    extra_instruction = ""
    if AFFIRM_PATTERNS.search(body.message):
        extra_instruction = (
            "The merchant just gave explicit affirmative intent. Do NOT ask another "
            "qualifying question. Move straight into the concrete next action step "
            "(what happens next, what you need from them, or what you're doing now)."
        )

    prior_bodies = [t["message"] for t in conv["turns"] if t["from_role"] in ("vera",)]
    prompt = build_compose_prompt(
        category, merchant, trigger, customer, prior_bodies, extra_instruction
    )
    result = llm_compose(prompt)

    # --- Anti-repetition guard ------------------------------------------
    if result["body"] in conv["sent_bodies"]:
        result["body"] += " (following up on the above)"

    conv["turns"].append({"from_role": "vera", "message": result["body"]})
    conv["sent_bodies"].add(result["body"])
    conv["auto_reply_streak"] = 0

    return {
        "action": "send",
        "body": result["body"],
        "cta": result.get("cta", "open_ended"),
        "rationale": result.get("rationale", ""),
    }
